#################
#PHOTOBOOTH FILE#
#################

def run():
    print ("pass")

if __name__ == "__main__":
    run()