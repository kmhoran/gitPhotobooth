#!/usr/bin/python3
#################
#PHOTOBOOTH FILE#
#################

from photos import photobooth

